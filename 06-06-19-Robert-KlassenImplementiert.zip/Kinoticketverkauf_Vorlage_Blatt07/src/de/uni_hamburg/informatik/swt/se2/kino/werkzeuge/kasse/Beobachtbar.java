package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.kasse;

import java.util.Collection;
import java.util.HashSet;

public abstract class Beobachtbar 
{
	private Collection<Beobachter> _beobachter;
	
	public Beobachtbar()
	{
		_beobachter = new HashSet<Beobachter>();
	}
	
	public void fuegeBeobachterHinzu(Beobachter b)
	{
		_beobachter.add(b);
	}
	
	public void beobachteAenderungVorstellung() 
	{
		for(Beobachter beobachter: _beobachter)
		{
			beobachter.beachteVorstellungAenderung();
		}
	}
	public void beobachteAenderungDatum() 
	{
		for(Beobachter beobachter: _beobachter)
		{
			beobachter.beachteDatumAenderung();
		}
	}
	
}
