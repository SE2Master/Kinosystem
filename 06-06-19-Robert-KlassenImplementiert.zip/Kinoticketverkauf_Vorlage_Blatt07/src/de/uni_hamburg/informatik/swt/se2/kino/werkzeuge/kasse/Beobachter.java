package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.kasse;

public interface Beobachter 
{
	public void beachteVorstellungAenderung();
	public void beachteDatumAenderung();
}
