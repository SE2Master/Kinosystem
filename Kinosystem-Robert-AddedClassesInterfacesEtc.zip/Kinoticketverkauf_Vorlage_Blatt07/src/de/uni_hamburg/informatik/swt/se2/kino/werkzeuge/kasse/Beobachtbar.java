package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.kasse;

import java.util.Set;

public abstract class Beobachtbar {

	Set<Beobachter> _beobachtbar;
	
	public void fuegeBeobachterHinzu(Beobachter b){
		_beobachtbar.add(b);
	}
	
	private void vorstellungWurdeAusgewaehlt() {
		
	}
	
	private void DatumWUrdeAusgewaehlt() {
		
	}
	
}
