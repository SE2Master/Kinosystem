package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.kasse;

/**
 * Dieses Interface stellt die Methoden zur Beobachtung der Vorstellungen / des Datums zur Verfügung 
 * @author Zeugs
 *
 */
public interface Beobachter 
{
	/**
	 * Beachtet die Aenderung der Vorstellung
	 */
	public void beachteVorstellungAenderung();
	
	/**
	 * Beachtet die Aenderung des Datums
	 */
	public void beachteDatumAenderung();
}
