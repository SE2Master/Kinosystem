package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.kasse;

import java.util.Collection;
import java.util.HashSet;

/**
 * Diese abstrakte Klasse dient zur Initialisierung neuer Beobachter und
 * beobachtet Änderungen von Vorstellungen und Daten.
 * @author Zeugs
 */

public abstract class Beobachtbar 
{
	private Collection<Beobachter> _beobachter;
	
	/**
     * Initialisiert die Liste der Beobachter.
     */
	public Beobachtbar()
	{
		_beobachter = new HashSet<Beobachter>();
	}
	
	/**
	 * Fügt Beobachter zur Liste hinzu
	 */
	public void fuegeBeobachterHinzu(Beobachter b)
	{
		_beobachter.add(b);
	}
	
	/**
	 * beachtet die Aenderung der Beobachter in der Liste für die Vorstellung
	 */
	public void beobachteAenderungVorstellung() 
	{
		for(Beobachter beobachter: _beobachter)
		{
			beobachter.beachteVorstellungAenderung();
		}
	}
	
	/**
	 * beachtet die Aenderung der Beobachter in der Liste fürs Datum
	 */
	public void beobachteAenderungDatum() 
	{
		for(Beobachter beobachter: _beobachter)
		{
			beobachter.beachteDatumAenderung();
		}
	}
	
}
